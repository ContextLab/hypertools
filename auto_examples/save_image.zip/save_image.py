# -*- coding: utf-8 -*-
"""
=============================
Saving a plot
=============================

To save a plot, simply use the `save_path` kwarg, and specify where you want
the image to be saved, including the file extension (e.g. pdf)
"""

# sphinx_gallery_thumbnail_path = '_static/thumbnails/sphx_glr_save_image_thumb.png'

# Code source: Andrew Heusser
# License: MIT

# import
import hypertools as hyp

# load example data
data = hyp.load('weights_sample')

# plot
import os  # noqa: E402 (sphinx-gallery narrative section, not top-of-file)
import tempfile  # noqa: E402 (same)
save_path = os.path.join(tempfile.mkdtemp(), 'test-image.pdf')
hyp.plot(data, fmt='o', save_path=save_path)
